/*
 * Corso di Sistemi Operativi 2020
 * Schema soluzione seconda verifica: semafori
 *
 * Author: Riccardo Focardi
 */
#include <semaphore.h>

// dichiarazione semafori e variabili globali

// inizializza semafori e variabili
// ATTENZIONE dim è la dimensione del gruppo che deve entrare
// nell'imbuto.
void inizializza_sem(int dim) {
}
 
// distruggi i semafori
void distruggi_sem() {
}
 
// attende di entrare nell'imbuto
void entra_imbuto() {
}
 
// esce dall'imbuto
// ATTENZIONE usare una variabile intera condivisa per sapere 
// quante palline sono uscite (da proteggere con una sezione critica)!
void esci_imbuto() {
}

