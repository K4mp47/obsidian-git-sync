// variabili globali e semafori qui

// invocato all'inizio dal thread principale prima di creare gli snake
void init_sem() {
}

// invocato dal thread prima della terminazione del programma
void destroy_sem() {
}

// invia un carattere al thread id
void invia_char(int id, char c) {
}

// il thread id legge un carattere (bloccante se il carattere non è stato inviato)
char leggi_char(int id) {
}

// attende che il thread id abbia letto
void attendi_lettura(int id) {
}

// il thread id segnala che la lettura è avvenuta
void fatta_lettura(int id) {
}